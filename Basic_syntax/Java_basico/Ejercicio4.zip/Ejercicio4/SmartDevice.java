package Java_basico.Ejercicio4;

public class SmartDevice {

    double peso = 0;
    double precio = 0;
    String procesador = "";

    public SmartDevice(double peso, double precio, String procesador) {
        this.peso = peso;
        this.precio = precio;
        this.procesador = procesador;
    }
}
