package Java_basico.Ejercicio5;

public interface CocheCRUD {

    void save();

    void findAll();

    void delete();
}
